/**
 * KOTA'S CREATIVE HUB - Bilingual Translations
 * Capture | Create | Celebrate
 * Kodad, Telangana
 */

const translations = {
  en: {
    // Navigation
    navHome: "Home",
    navAbout: "About Us",
    navServices: "Our Services",
    navPricing: "Pricing & Packages",
    navGallery: "Photography Gallery",
    navThemes: "Creative Themes",
    navVideo: "Video Gallery",
    navContact: "Contact Us",
    navBooking: "Book a Session",

    // Hero Section
    heroBadge: "✨ KODAD'S PREMIER CREATIVE STUDIO & CELEBRATION DESTINATION",
    heroTitle: "Every Moment Deserves to Be Beautifully Captured.",
    heroDesc: "From precious newborn memories to magical celebrations, we capture your happiest moments and turn them into unforgettable memories.",
    heroBtnGallery: "Explore Our Gallery",
    heroBtnBook: "Book Your Session",
    heroBtnWhatsApp: "Contact Us on WhatsApp",
    heroSubnote: "1097 & 1098, Chandramouli Complex, Beside Ranga Theater, Kodad · Call: 97054 26842 / 99486 43909",

    // Highlight Strip
    strip1Title: "Baby & Kids Photography",
    strip1Desc: "Starting from ₹2,000 · Themed studio sets",
    strip2Title: "Party Room & Celebrations",
    strip2Desc: "₹1,500 / 1½ Hours · 40–50 Capacity",
    strip3Title: "LED Screen Services",
    strip3Desc: "Starting from ₹7,000 · High-definition displays",
    strip4Title: "Grand Entry & Catering",
    strip4Desc: "Fire & smoke entry, custom decor, food options",

    // About Section
    aboutEyebrow: "About Us",
    aboutHeading: "Welcome to KOTA'S CREATIVE HUB",
    aboutLead: "Located in Kodad, Telangana, KOTA'S CREATIVE HUB provides professional baby and kids photography, a private celebration party room, theme decorations, photo & video editing, and high-impact LED screen services.",
    aboutP1: "Situated conveniently at 1097 and 1098, 2nd Floor, Chandramouli Complex beside Ranga Theater in Kodad, we provide families, parents, and event organizers with specialized creative settings. From delicate newborn setups and imaginative studio themes to celebratory birthday gatherings, customized decorations, and vivid LED displays, our passion is turning life's most precious occasions into timeless art.",
    aboutNoticeTitle: "🛡️ Child Safety & Parent Privacy Commitment",
    aboutNoticeText: "We deeply respect family privacy and infant safety. All baby photographs showcased on our website are shared with express parental/guardian consent in a warm, sanitized studio environment.",

    // Services Section
    servicesEyebrow: "Our Services",
    servicesHeading: "Comprehensive Creative & Celebration Services",
    servicesSubtitle: "Everything you need under one roof to capture memories and celebrate life's greatest moments.",
    srvATitle: "Kids & Newborn Photography",
    srvADesc: "Delicate newborn photoshoots, baby milestone photography, birthday shoots, creative baby themes, family portraits, and traditional baby poses.",
    srvBTitle: "Creative Photography Studio",
    srvBDesc: "Professional studio photoshoots, maternity photography, individual & family portraits, creative themed photography, and special occasion shoots.",
    srvCTitle: "Party Rooms & Decorations",
    srvCDesc: "Private decorated celebration room for birthday parties, baby showers, and milestone family gatherings with capacity for 40–50 members.",
    srvDTitle: "Creative Sets & Backdrops",
    srvDDesc: "Handcrafted, imaginative photography backdrops: Space, Moon & Stars, Nature & Forest, Flower, Vintage, and Musical themes.",
    srvETitle: "Professional Editing Studio",
    srvEDesc: "High-end digital photo editing, cinematic video editing, premium album designing, color grading, and creative photo retouching.",
    srvFTitle: "LED Screens & Event Services",
    srvFDesc: "High-definition LED display screen rentals, birthday celebration presentations, live camera feeds, and technical event visual support.",

    // Themes Section
    themesEyebrow: "Studio Setups",
    themesHeading: "Our Handcrafted Creative Themes",
    themesSubtitle: "Explore our imaginative photography environments designed specifically to make newborn, baby, and kids portraits magical.",

    // Pricing Section
    pricingEyebrow: "Packages & Investment",
    pricingHeading: "Transparent Pricing & Packages",
    pricingSubtitle: "Official rates directly from KOTA'S CREATIVE HUB. Clear pricing with zero hidden surprises.",

    // Gallery Section
    galleryEyebrow: "Our Portfolio",
    galleryHeading: "Real Photography & Celebrations",
    gallerySubtitle: "Every photo shown here is from our actual baby photoshoots, creative studio setups, and party room celebrations in Kodad.",

    // Video Gallery Section
    videoEyebrow: "Video Gallery",
    videoHeading: "Experience KOTA'S CREATIVE HUB in Motion",
    videoSubtitle: "Watch actual video footage captured at our studio showcasing our celebration spaces, party ambience, and high-definition event displays.",
    videoTitle: "Party Room & Studio Showreel",
    videoDesc: "Take a virtual walkthrough of our decorated party room, cake cutting stage, and photography studio setups. Message us directly on WhatsApp to check date availability.",

    // Booking Section
    bookingEyebrow: "Book a Session",
    bookingHeading: "Send a Booking Enquiry",
    bookingSubtitle: "Fill in your preferred details below to launch a direct WhatsApp enquiry to Kota Satwik & Kota Srinivas Rao at 919705426842.",
    formLabelName: "Customer Name *",
    formLabelPhone: "Mobile Number (10 digits) *",
    formLabelService: "Select Photography or Celebration Service *",
    formLabelDate: "Preferred Date *",
    formLabelRequirements: "Additional Requirements / Notes",
    formSubmitBtn: "💬 Send Booking Enquiry via WhatsApp",
    formNoticeText: "Notice: Submitting this form opens WhatsApp with all your enquiry details prefilled. It does NOT automatically confirm a booking without direct confirmation from KOTA'S CREATIVE HUB.",
    formErrorName: "Please enter your full name.",
    formErrorPhone: "Please enter a valid 10-digit Indian phone number.",
    formErrorDate: "Please select today or a future date.",

    // Contact Section
    contactEyebrow: "Get in Touch",
    contactHeading: "Contact KOTA'S CREATIVE HUB",
    contactSubtitle: "We welcome you to visit our studio in Kodad or reach out directly to plan your shoot or celebration.",

    // Floating Button
    floatWhatsAppText: "Chat on WhatsApp"
  },

  te: {
    // Navigation
    navHome: "హోమ్",
    navAbout: "మా గురించి",
    navServices: "మా సేవలు",
    navPricing: "ధరలు & ప్యాకేజీలు",
    navGallery: "ఫోటో గ్యాలరీ",
    navThemes: "క్రియేటివ్ థీమ్స్",
    navVideo: "వీడియో గ్యాలరీ",
    navContact: "మమ్మల్ని సంప్రదించండి",
    navBooking: "సెషన్ బుక్ చేయండి",

    // Hero Section
    heroBadge: "✨ కోదాడలో అగ్రగామి క్రియేటివ్ స్టూడియో & వేడుకల వేదిక",
    heroTitle: "ప్రతీ మధుర క్షణం అద్భుతంగా పదిలపరచబడటానికి అర్హమైనది.",
    heroDesc: "అపురూపమైన పసిపిల్లల జ్ఞాపకాల నుండి అద్భుతమైన వేడుకల వరకు, మీ ఆనందకర క్షణాలను ఎప్పటికీ గుర్తుండిపోయే మధురానుభూతులుగా తీర్చిదిద్దుతాము.",
    heroBtnGallery: "మా గ్యాలరీని చూడండి",
    heroBtnBook: "సెషన్ బుక్ చేసుకోండి",
    heroBtnWhatsApp: "వాట్సాప్‌లో సంప్రదించండి",
    heroSubnote: "1097 & 1098, చంద్రమౌళి కాంప్లెక్స్, రంగా థియేటర్ పక్కన, కోదాడ · కాల్ చేయండి: 97054 26842 / 99486 43909",

    // Highlight Strip
    strip1Title: "బేబీ & కిడ్స్ ఫోటోగ్రఫీ",
    strip1Desc: "ప్రారంభ ధర ₹2,000 నుండి · థీమ్ స్టూడియో సెట్స్",
    strip2Title: "పార్టీ రూమ్ & వేడుకలు",
    strip2Desc: "₹1,500 / 1½ గంటలు · 40–50 మంది సామర్థ్యం",
    strip3Title: "LED స్క్రీన్ సర్వీసెస్",
    strip3Desc: "ప్రారంభ ధర ₹7,000 నుండి · హై-డెఫినిషన్ డిస్ప్లేలు",
    strip4Title: "గ్రాండ్ ఎంట్రీ & క్యాటరింగ్",
    strip4Desc: "ఫైర్ & స్మోక్ ఎంట్రీ, స్పెషల్ డెకర్, భోజన వసతి",

    // About Section
    aboutEyebrow: "మా గురించి",
    aboutHeading: "కోటాస్ క్రియేటివ్ హబ్ కు స్వాగతం",
    aboutLead: "తెలంగాణలోని కోదాడలో ఉన్న కోటాస్ క్రియేటివ్ హబ్, ప్రొఫెషనల్ బేబీ ఫోటోగ్రఫీ, ప్రైవేట్ పార్టీ రూమ్, థీమ్ డెకరేషన్స్, ఫోటో & వీడియో ఎడిటింగ్ మరియు ఎల్ఈడీ స్క్రీన్ సేవలను అందిస్తోంది.",
    aboutP1: "కోదాడలోని రంగా థియేటర్ పక్కన, చంద్రమౌళి కాంప్లెక్స్ 2వ అంతస్తు (1097 & 1098) లో ఉన్న మా స్టూడియోలో కుటుంబాలకు మరియు పిల్లలకు సరికొత్త క్రియేటివ్ సెట్టింగ్‌లు సిద్ధంగా ఉన్నాయి. పసిపాపల సున్నితమైన ఫోటోల నుండి పుట్టినరోజు వేడుకలు, కలర్‌ఫుల్ డెకరేషన్లు, హై-క్వాలిటీ ఎల్ఈడీ డిస్ప్లేల వరకు జీవితంలోని అమూల్యమైన క్షణాలను అద్భుత కళారూపాలుగా మార్చడమే మా లక్ష్యం.",
    aboutNoticeTitle: "🛡️ పిల్లల భద్రత & గోప్యతా రక్షణ నిబద్ధత",
    aboutNoticeText: "మేము కుటుంబాల ప్రైవసీ మరియు పిల్లల సంరక్షణను అత్యంత ప్రాధాన్యతగా భావిస్తాము. మా వెబ్‌సైట్‌లోని అన్ని బేబీ ఫోటోలు తల్లిదండ్రుల పూర్తి అనుమతితో మరియు పరిశుభ్రమైన వాతావరణంలో తీయబడ్డాయి.",

    // Services Section
    servicesEyebrow: "మా సేవలు",
    servicesHeading: "సమగ్ర క్రియేటివ్ & వేడుకల సేవలు",
    servicesSubtitle: "మీ జీవితంలోని మధుర క్షణాలను రికార్డ్ చేయడానికి మరియు ఆనందంగా వేడుక చేసుకోవడానికి అవసరమైనవన్నీ ఒకే చోట.",
    srvATitle: "కిడ్స్ & న్యూబార్న్ ఫోటోగ్రఫీ",
    srvADesc: "నవజాత శిశువుల ఫోటోషూట్‌లు, బేబీ మైల్‌స్టోన్ ఫొటోగ్రఫీ, పుట్టినరోజు షూట్‌లు, క్రియేటివ్ బేబీ థీమ్‌లు, ఫ్యామిలీ పోర్ట్రెయిట్‌లు.",
    srvBTitle: "క్రియేటివ్ ఫోటోగ్రఫీ స్టూడియో",
    srvBDesc: "ప్రొఫెషనల్ స్టూడియో ఫోటోషూట్‌లు, మెటర్నిటీ ఫోటోగ్రఫీ, వ్యక్తిగత & ఫ్యామిలీ పోర్ట్రెయిట్‌లు మరియు ప్రత్యేక సందర్భాల ఫోటోషూట్లు.",
    srvCTitle: "పార్టీ రూమ్స్ & డెకరేషన్స్",
    srvCDesc: "పుట్టినరోజు వేడుకలు, బేబీ షవర్ మరియు కుటుంబ వేడుకల కోసం ప్రత్యేకంగా అలంకరించిన ప్రైవేట్ పార్టీ రూమ్ (40–50 మంది సామర్థ్యం).",
    srvDTitle: "క్రియేటివ్ సెట్స్ & బ్యాక్‌డ్రాప్స్",
    srvDDesc: "అద్భుతమైన ప్రత్యేక ఫోటో బ్యాక్‌డ్రాప్‌లు: స్పేస్, చందమామ & నక్షత్రాలు, అడవి-ప్రకృతి, పూల తోట, వింటేజ్ పియానో థీమ్‌లు.",
    srvETitle: "ప్రొఫెషనల్ ఎడిటింగ్ స్టూడియో",
    srvEDesc: "అత్యాధునిక డిజిటల్ ఫోటో ఎడిటింగ్, సినిమాటిక్ వీడియో ఎడిటింగ్, ప్రీమియం ఆల్బమ్ డిజైనింగ్, కలర్ గ్రేడింగ్ మరియు రీటచింగ్.",
    srvFTitle: "LED స్క్రీన్స్ & ఈవెంట్ సర్వీసెస్",
    srvFDesc: "హై-డెఫినిషన్ ఎల్ఈడీ డిస్ప్లే స్క్రీన్ అద్దెలు, పుట్టినరోజు స్లైడ్‌షోలు, లైవ్ కెమెరా ఫీడ్ మరియు సమగ్ర ఈవెంట్ సాంకేతిక సహకారం.",

    // Themes Section
    themesEyebrow: "స్టూడియో సెటప్‌లు",
    themesHeading: "మా ప్రత్యేక క్రియేటివ్ థీమ్‌లు",
    themesSubtitle: "చిన్నారుల అందమైన ఫోటోషూట్లను మాయా ప్రపంచంలా మార్చేందుకు మేము ప్రత్యేకంగా రూపొందించిన కళాత్మక థీమ్‌లను చూడండి.",

    // Pricing Section
    pricingEyebrow: "ప్యాకేజీలు & పెట్టుబడి",
    pricingHeading: "స్పష్టమైన ధరలు & ప్యాకేజీలు",
    pricingSubtitle: "కోటాస్ క్రియేటివ్ హబ్ నుండి నేరుగా అధికారిక ధరలు. ఎలాంటి దాచిన ఛార్జీలు లేకుండా పూర్తి స్పష్టత.",

    // Gallery Section
    galleryEyebrow: "మా పోర్ట్‌ఫోలియో",
    galleryHeading: "నిజమైన ఫోటోగ్రఫీ & వేడుకలు",
    gallerySubtitle: "ఇక్కడ చూపిన ప్రతి ఛాయాచిత్రం కోదాడలోని మా స్టూడియోలో తీసిన వాస్తవ బేబీ ఫోటోషూట్లు మరియు పార్టీ రూమ్ వేడుకలదే.",

    // Video Gallery Section
    videoEyebrow: "వీడియో గ్యాలరీ",
    videoHeading: "కోటాస్ క్రియేటివ్ హబ్ అనుభవాన్ని వీడియోలో వీక్షించండి",
    videoSubtitle: "మా వేడుకల గదులు, పార్టీ వాతావరణం మరియు హై-డెఫినిషన్ ఎల్ఈడీ డిస్ప్లేలను ప్రత్యక్షంగా చూపే అసలైన వీడియోలు చూడండి.",
    videoTitle: "పార్టీ రూమ్ & స్టూడియో షోరీల్",
    videoDesc: "అలంకరించిన మా పార్టీ రూమ్, కేక్ కటింగ్ వేదిక మరియు ఫోటోగ్రఫీ స్టూడియోను వర్చువల్‌గా చూడండి. తేదీ లభ్యత కోసం వాట్సాప్‌లో సంప్రదించండి.",

    // Booking Section
    bookingEyebrow: "సెషన్ బుక్ చేసుకోండి",
    bookingHeading: "బుకింగ్ విచారణ పంపండి",
    bookingSubtitle: "మీ వివరాలను క్రింద నమోదు చేసి, కోటా సాత్విక్ & కోటా శ్రీనివాసరావు గారికి (919705426842) నేరుగా వాట్సాప్ విచారణ పంపండి.",
    formLabelName: "కస్టమర్ పేరు *",
    formLabelPhone: "మొబైల్ నంబర్ (10 అంకెలు) *",
    formLabelService: "ఫోటోగ్రఫీ లేదా వేడుకల సేవను ఎంచుకోండి *",
    formLabelDate: "కావాల్సిన తేదీ *",
    formLabelRequirements: "అదనపు వివరాలు / అవసరాలు",
    formSubmitBtn: "💬 వాట్సాప్ ద్వారా బుకింగ్ విచారణ పంపండి",
    formNoticeText: "గమనిక: ఈ ఫారమ్ సమర్పించడం వల్ల వివరాలు వాట్సాప్‌లో సిద్ధమవుతాయి. కోటాస్ క్రియేటివ్ హబ్ అధికారిక నిర్ధారణ తర్వాతే బుకింగ్ ఖరారవుతుంది.",
    formErrorName: "దయచేసి మీ పూర్తి పేరును నమోదు చేయండి.",
    formErrorPhone: "దయచేసి చెల్లుబాటు అయ్యే 10 అంకెల మొబైల్ నంబర్ నమోదు చేయండి.",
    formErrorDate: "దయచేసి ఈ రోజు లేదా భవిష్యత్తు తేదీని ఎంచుకోండి.",

    // Contact Section
    contactEyebrow: "సంప్రదించండి",
    contactHeading: "కోటాస్ క్రియేటివ్ హబ్‌ను సంప్రదించండి",
    contactSubtitle: "మీ షూట్ లేదా వేడుకను ప్లాన్ చేసుకోవడానికి కోదాడలోని మా స్టూడియోని సందర్శించండి లేదా నేరుగా మాట్లాడండి.",

    // Floating Button
    floatWhatsAppText: "వాట్సాప్‌లో మాట్లాడండి"
  }
};

