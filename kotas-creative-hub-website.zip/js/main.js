/**
 * KOTA'S CREATIVE HUB - Master JavaScript
 * Capture | Create | Celebrate
 * Kodad, Telangana
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Current Year
  const yearEl = document.getElementById('currentYear');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // 2. Minimum Date for Booking
  const dateInput = document.getElementById('bookingDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
  }

  // 3. Mobile Navigation Menu Toggle
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const navMenu = document.getElementById('navMenu');

  if (hamburgerBtn && navMenu) {
    hamburgerBtn.addEventListener('click', () => {
      const isActive = hamburgerBtn.classList.toggle('active');
      navMenu.classList.toggle('active', isActive);
      hamburgerBtn.setAttribute('aria-expanded', String(isActive));
    });

    // Close menu when clicking any nav link
    navMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburgerBtn.classList.remove('active');
        navMenu.classList.remove('active');
        hamburgerBtn.setAttribute('aria-expanded', 'false');
      });
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!navMenu.contains(e.target) && !hamburgerBtn.contains(e.target)) {
        hamburgerBtn.classList.remove('active');
        navMenu.classList.remove('active');
        hamburgerBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // 4. Bilingual Language Switcher (English <-> Telugu)
  let currentLang = localStorage.getItem('kotas_lang') || 'en';

  const applyLanguage = (lang) => {
    if (typeof translations === 'undefined' || !translations[lang]) return;
    currentLang = lang;
    localStorage.setItem('kotas_lang', lang);
    document.documentElement.lang = lang;

    // Update all i18n translatable elements
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (translations[lang] && translations[lang][key]) {
        el.textContent = translations[lang][key];
      }
    });

    // Update toggle button text
    const langBtn = document.getElementById('langToggleBtn');
    if (langBtn) {
      if (lang === 'te') {
        langBtn.innerHTML = '🌐 <span>English</span>';
        langBtn.setAttribute('aria-label', 'Switch website to English');
      } else {
        langBtn.innerHTML = '🌐 <span>తెలుగు</span>';
        langBtn.setAttribute('aria-label', 'వెబ్‌సైట్‌ను తెలుగులోకి మార్చండి');
      }
    }
  };

  const langToggleBtn = document.getElementById('langToggleBtn');
  if (langToggleBtn) {
    langToggleBtn.addEventListener('click', () => {
      const nextLang = currentLang === 'en' ? 'te' : 'en';
      applyLanguage(nextLang);
    });
    // Initialize saved or default language
    applyLanguage(currentLang);
  }

  // 5. Gallery Category Filter Controls
  const filterButtons = document.querySelectorAll('.filter-btn');
  const galleryCards = document.querySelectorAll('.gallery-card');

  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      filterButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      galleryCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filterValue === 'all' || category === filterValue) {
          card.style.display = '';
          card.classList.remove('is-hidden');
        } else {
          card.style.display = 'none';
          card.classList.add('is-hidden');
        }
      });
    });
  });

  // 6. Interactive Lightbox Modal
  const lightboxModal = document.getElementById('lightboxModal');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  const lightboxClose = document.getElementById('lightboxClose');
  const lightboxPrev = document.getElementById('lightboxPrev');
  const lightboxNext = document.getElementById('lightboxNext');

  let zoomableElements = [];
  let currentZoomIndex = 0;

  const updateZoomableList = () => {
    // Only select visible zoomable elements
    zoomableElements = Array.from(document.querySelectorAll('[data-zoom]')).filter(el => {
      return el.offsetParent !== null;
    });
  };

  const showLightboxItem = (index) => {
    if (!zoomableElements.length) return;
    if (index < 0) index = zoomableElements.length - 1;
    if (index >= zoomableElements.length) index = 0;
    currentZoomIndex = index;

    const target = zoomableElements[currentZoomIndex];
    const fullSrc = target.getAttribute('data-full') || target.querySelector('img')?.src;
    const caption = target.getAttribute('data-title') || target.querySelector('img')?.alt || "KOTA'S CREATIVE HUB";

    if (lightboxImg && fullSrc) {
      lightboxImg.src = fullSrc;
      lightboxImg.alt = caption;
    }
    if (lightboxCaption) {
      lightboxCaption.textContent = caption;
    }
  };

  const openLightbox = (index) => {
    updateZoomableList();
    if (!lightboxModal) return;
    lightboxModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    showLightboxItem(index);
  };

  const closeLightbox = () => {
    if (!lightboxModal) return;
    lightboxModal.classList.remove('active');
    document.body.style.overflow = '';
  };

  document.querySelectorAll('[data-zoom]').forEach((el) => {
    el.addEventListener('click', (e) => {
      // Prevent opening lightbox if user clicked a direct CTA button inside the card
      if (e.target.closest('a') || e.target.closest('button')) return;
      updateZoomableList();
      const idx = zoomableElements.indexOf(el);
      if (idx !== -1) {
        openLightbox(idx);
      }
    });
  });

  lightboxClose?.addEventListener('click', closeLightbox);
  lightboxPrev?.addEventListener('click', () => showLightboxItem(currentZoomIndex - 1));
  lightboxNext?.addEventListener('click', () => showLightboxItem(currentZoomIndex + 1));

  lightboxModal?.addEventListener('click', (e) => {
    if (e.target === lightboxModal) {
      closeLightbox();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (!lightboxModal?.classList.contains('active')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') showLightboxItem(currentZoomIndex - 1);
    if (e.key === 'ArrowRight') showLightboxItem(currentZoomIndex + 1);
  });

  // 7. Quick Service Select Helper
  const serviceSelect = document.getElementById('bookingService');
  document.querySelectorAll('[data-select-service]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const serviceName = btn.getAttribute('data-select-service');
      if (serviceSelect && serviceName) {
        for (let i = 0; i < serviceSelect.options.length; i++) {
          if (serviceSelect.options[i].value.toLowerCase().includes(serviceName.toLowerCase()) ||
              serviceName.toLowerCase().includes(serviceSelect.options[i].value.toLowerCase())) {
            serviceSelect.selectedIndex = i;
            break;
          }
        }
      }
      const bookingSection = document.getElementById('booking');
      if (bookingSection) {
        bookingSection.scrollIntoView({ behavior: 'smooth' });
        setTimeout(() => {
          document.getElementById('bookingName')?.focus();
        }, 600);
      }
    });
  });

  // 8. Booking Form Validation & WhatsApp Submission
  const bookingForm = document.getElementById('bookingForm');
  if (bookingForm) {
    const nameInput = document.getElementById('bookingName');
    const phoneInput = document.getElementById('bookingPhone');
    const nameGroup = document.getElementById('nameGroup');
    const phoneGroup = document.getElementById('phoneGroup');
    const dateGroup = document.getElementById('dateGroup');

    // Real-time phone number cleanup (only digits, max 10)
    phoneInput?.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10);
    });

    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      // Reset error states
      nameGroup?.classList.remove('has-error');
      phoneGroup?.classList.remove('has-error');
      dateGroup?.classList.remove('has-error');

      const nameVal = nameInput ? nameInput.value.trim() : '';
      const phoneVal = phoneInput ? phoneInput.value.trim() : '';
      const serviceVal = serviceSelect ? serviceSelect.value : '';
      const dateVal = dateInput ? dateInput.value : '';
      const reqVal = document.getElementById('bookingRequirements')?.value.trim() || '';

      // Validate Name
      if (!nameVal || nameVal.length < 2) {
        nameGroup?.classList.add('has-error');
        isValid = false;
      }

      // Validate Phone (10-digit Indian mobile number starting 6, 7, 8, or 9)
      const phoneRegex = /^[6-9]\d{9}$/;
      if (!phoneVal || !phoneRegex.test(phoneVal)) {
        phoneGroup?.classList.add('has-error');
        isValid = false;
      }

      // Validate Date (must be today or later)
      if (!dateVal) {
        dateGroup?.classList.add('has-error');
        isValid = false;
      } else {
        const selectedDate = new Date(dateVal);
        const todayDate = new Date();
        todayDate.setHours(0, 0, 0, 0);
        if (selectedDate < todayDate) {
          dateGroup?.classList.add('has-error');
          isValid = false;
        }
      }

      if (!isValid) {
        // Focus first invalid input
        const firstError = bookingForm.querySelector('.has-error input, .has-error select');
        firstError?.focus();
        return;
      }

      // Format Date for readability
      let formattedDate = dateVal;
      try {
        const parts = dateVal.split('-');
        if (parts.length === 3) {
          formattedDate = `${parts[2]}/${parts[1]}/${parts[0]}`;
        }
      } catch (err) {
        formattedDate = dateVal;
      }

      // Construct WhatsApp Message
      const waText = 
`*NEW BOOKING ENQUIRY - KOTA'S CREATIVE HUB*
━━━━━━━━━━━━━━━━━━━━━
👤 *Customer Name:* ${nameVal}
📞 *Mobile Number:* ${phoneVal}
🎯 *Selected Service:* ${serviceVal}
📅 *Preferred Date:* ${formattedDate}
📝 *Requirements / Notes:* ${reqVal || 'No special requirements specified'}
━━━━━━━━━━━━━━━━━━━━━
📍 1097 & 1098, 2nd Floor, Chandramouli Complex, Beside Ranga Theater, Kodad, Telangana – 508206
Sent via kotascreativehub.com enquiry system`;

      const waUrl = `https://wa.me/919705426842?text=${encodeURIComponent(waText)}`;

      // Show temporary confirmation message above submit button
      let alertBox = document.getElementById('formSuccessAlert');
      if (!alertBox) {
        alertBox = document.createElement('div');
        alertBox.id = 'formSuccessAlert';
        alertBox.style.padding = '1rem 1.25rem';
        alertBox.style.marginBottom = '1.25rem';
        alertBox.style.borderRadius = '12px';
        alertBox.style.background = '#e6f7ed';
        alertBox.style.border = '1px solid #34c759';
        alertBox.style.color = '#1b5e20';
        alertBox.style.fontSize = '0.95rem';
        alertBox.style.fontWeight = '600';
        bookingForm.insertBefore(alertBox, bookingForm.querySelector('.btn-submit-wa').parentElement);
      }

      alertBox.innerHTML = `✅ <strong>Opening WhatsApp...</strong> Your enquiry has been prepared! If WhatsApp doesn't open automatically, <a href="${waUrl}" target="_blank" rel="noopener noreferrer" style="color:#0a7c42;text-decoration:underline;">click here to send message</a>.`;
      alertBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      // Open WhatsApp in new tab / app
      window.open(waUrl, '_blank', 'noopener,noreferrer');

      // Reset form fields after brief delay
      setTimeout(() => {
        bookingForm.reset();
        if (dateInput) {
          dateInput.min = new Date().toISOString().split('T')[0];
        }
      }, 1500);
    });
  }
});
