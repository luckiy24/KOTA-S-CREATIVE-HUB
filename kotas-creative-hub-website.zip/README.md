# KOTA'S CREATIVE HUB — Official Business Website
**Capture | Create | Celebrate**  
*Kodad, Telangana – 508206, India*

---

## 🌟 Overview
**KOTA'S CREATIVE HUB** is a premier creative photography studio, kids milestone photography destination, luxury private party celebration venue, event decoration hub, and event visual LED screen service provider located in Kodad, Telangana.

This production-ready business website is engineered to reflect a modern, luxury photography aesthetic with soft cream (`#faf9f6`), pristine white (`#ffffff`), soft pastel pink (`#fdf2f4`), deep luxury navy (`#0a1128`), and metallic gold accents (`#c5a059`).

---

## 📍 Business Information & Contacts

- **Business Name:** KOTA'S CREATIVE HUB
- **Tagline:** Capture | Create | Celebrate
- **Studio Address:** 1097 and 1098, 2nd Floor, Chandramouli Complex, Beside Ranga Theater, Kodad, Telangana – 508206.
- **Key Contacts:**
  - **Kota Satwik:** 97054 26842 ([Click to Call](tel:+919705426842))
  - **Kota Srinivas Rao:** 99486 43909 ([Click to Call](tel:+919948643909))
- **Official WhatsApp:** `919705426842` ([Chat on WhatsApp](https://wa.me/919705426842))
- **Instagram Handle:** [@KOTA_S__CREATIVE_HUB](https://www.instagram.com/KOTA_S__CREATIVE_HUB)

---

## 🎯 The Six Official Services

1. **Kids & Newborn Photography** (Starting from ₹2,000)
   - Newborn photoshoots, baby milestone photography, birthday shoots, family portraits, and traditional & modern baby poses.
2. **Creative Photography Studio**
   - Professional studio photoshoots, maternity photography, portraits, and special occasion shoots.
3. **Party Rooms & Celebrations** (₹1,500 / 1½ Hours)
   - Private decorated celebration room for birthday parties, baby showers, and milestone family gatherings with capacity for 40–50 members (package includes up to 10 members).
4. **Creative Sets & Backdrops**
   - Handcrafted creative themes: Moon & Stars, Flower Blossom, Nature & Forest, Musical Piano, Honey Bee Adventure, and Fairytale Storybook.
5. **Professional Editing Studio**
   - High-end digital photo editing, cinematic event video editing, custom album designing, and retouching.
6. **LED Screens & Event Services** (Starting from ₹7,000)
   - High-definition LED display screen rentals, birthday slideshows, live feeds, and event visual support.

### ✨ Additional Celebration Facilities
- **Grand Fire Entry:** Dazzling pyrotechnic cold fire entry effects.
- **Smoke Entry:** Atmospheric low-lying fog and dramatic entrance smoke.
- **Custom Welcome Boards:** Personalized easels and themed entrance signages.
- **Customized Decorations:** Full theme-based balloon setups, arches, and backdrops.
- **Food & Catering Services:** Full catering arrangements tailored to guest counts.
- **40–50 Member Capacity:** Comfortable private celebration hall setting.

---

## 💻 Tech Stack & Features

- **Semantic HTML5 & Schema.org:** Complete `LocalBusiness` JSON-LD structured data for rich search engine indexing.
- **Vanilla CSS3:** Modern responsive layout using CSS Grid, Flexbox, custom variables, responsive typography, and smooth transitions without bulky dependencies.
- **Vanilla JavaScript (ES6+):**
  - **Bilingual Language Switcher:** Instant, zero-reload switching between English and Telugu (`తెలుగు`) with `localStorage` persistence.
  - **Direct WhatsApp Booking Engine:** Validates customer name, 10-digit Indian mobile number, selected service, and future date; pre-fills and opens WhatsApp chat directed to `919705426842`.
  - **Interactive Lightbox Modal:** Full-screen zoom and preview for studio photos with previous/next keyboard and touch navigation.
  - **Category-Filtered Photo Gallery:** Real-time filtering across Newborn, Baby & Kids, Creative Themes, and Party Rooms.
  - **Video Showcase:** Embedded native video player presenting the studio tour showreel.

---

## 🚀 Running Locally

You can preview the website instantly using any local web server or by opening `index.html` directly in any modern browser:

```powershell
# Python 3
python -m http.server 8000

# Node.js
npx serve .
```

Then visit `http://localhost:8000` in your browser.

---

## 🧪 Testing & Quality Assurance

Run the automated test suites:

```powershell
# Run Python Unit Test Suite (13 tests)
python tests/test_suite.py

# Run Node.js DOM QA Suite (51 assertions)
node tests/dom_qa.js
```

Both suites verify 100% of business constraints, assets, pricing, bilingual keys, and DOM bindings.

